﻿namespace Jreng_Kitchen
{
    partial class btn_penjual
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_laporan = new System.Windows.Forms.DataGridView();
            this.lb_laporanPenjualan = new System.Windows.Forms.Label();
            this.btn_kembali = new System.Windows.Forms.Button();
            this.lb_bestMerchant = new System.Windows.Forms.Label();
            this.lb_potonganTerbanyak = new System.Windows.Forms.Label();
            this.lb_pesananWA = new System.Windows.Forms.Label();
            this.lb_akumulasi = new System.Windows.Forms.Label();
            this.lb_hasilBestMerchant = new System.Windows.Forms.Label();
            this.lb_hasilPotonganTerbanyak = new System.Windows.Forms.Label();
            this.lb_hasilPesananWA = new System.Windows.Forms.Label();
            this.lb_hasilAkumulasi = new System.Windows.Forms.Label();
            this.lb_menu1 = new System.Windows.Forms.Label();
            this.panel = new System.Windows.Forms.Panel();
            this.btn_beranda = new System.Windows.Forms.Button();
            this.btn_penjualan = new System.Windows.Forms.Button();
            this.btn_riwayat = new System.Windows.Forms.Button();
            this.btn_produk = new System.Windows.Forms.Button();
            this.btn_pesan = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel_bestMerchant = new System.Windows.Forms.Panel();
            this.pb_satu = new System.Windows.Forms.PictureBox();
            this.panel_hasilBestMerchant = new System.Windows.Forms.Panel();
            this.panel_potonganTerbanyak = new System.Windows.Forms.Panel();
            this.panel_pesananWA = new System.Windows.Forms.Panel();
            this.panel_akumulasi = new System.Windows.Forms.Panel();
            this.lb_garis = new System.Windows.Forms.Label();
            this.panel_laporanPeriode = new System.Windows.Forms.Panel();
            this.lb_bulanTahun = new System.Windows.Forms.Label();
            this.lb_laporanPeriode = new System.Windows.Forms.Label();
            this.panel_menu1 = new System.Windows.Forms.Panel();
            this.pb_rank1 = new System.Windows.Forms.PictureBox();
            this.panel_menu2 = new System.Windows.Forms.Panel();
            this.lb_menu2 = new System.Windows.Forms.Label();
            this.pb_rank2 = new System.Windows.Forms.PictureBox();
            this.panel_menu3 = new System.Windows.Forms.Panel();
            this.pb_rank3 = new System.Windows.Forms.PictureBox();
            this.lb_menu3 = new System.Windows.Forms.Label();
            this.lb_menu4 = new System.Windows.Forms.Label();
            this.panel_menu4 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lb_menu5 = new System.Windows.Forms.Label();
            this.lb_menuFavorit = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_laporan)).BeginInit();
            this.panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel_bestMerchant.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_satu)).BeginInit();
            this.panel_hasilBestMerchant.SuspendLayout();
            this.panel_potonganTerbanyak.SuspendLayout();
            this.panel_pesananWA.SuspendLayout();
            this.panel_akumulasi.SuspendLayout();
            this.panel_laporanPeriode.SuspendLayout();
            this.panel_menu1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_rank1)).BeginInit();
            this.panel_menu2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_rank2)).BeginInit();
            this.panel_menu3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_rank3)).BeginInit();
            this.panel_menu4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgv_laporan
            // 
            this.dgv_laporan.AllowUserToAddRows = false;
            this.dgv_laporan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_laporan.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_laporan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_laporan.Location = new System.Drawing.Point(286, 91);
            this.dgv_laporan.MultiSelect = false;
            this.dgv_laporan.Name = "dgv_laporan";
            this.dgv_laporan.ReadOnly = true;
            this.dgv_laporan.RowHeadersVisible = false;
            this.dgv_laporan.RowHeadersWidth = 82;
            this.dgv_laporan.RowTemplate.Height = 33;
            this.dgv_laporan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_laporan.Size = new System.Drawing.Size(1038, 198);
            this.dgv_laporan.TabIndex = 1;
            // 
            // lb_laporanPenjualan
            // 
            this.lb_laporanPenjualan.AutoSize = true;
            this.lb_laporanPenjualan.Font = new System.Drawing.Font("Cambria", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_laporanPenjualan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(123)))), ((int)(((byte)(78)))));
            this.lb_laporanPenjualan.Location = new System.Drawing.Point(632, 19);
            this.lb_laporanPenjualan.Name = "lb_laporanPenjualan";
            this.lb_laporanPenjualan.Size = new System.Drawing.Size(394, 51);
            this.lb_laporanPenjualan.TabIndex = 2;
            this.lb_laporanPenjualan.Text = "Laporan Penjualan";
            // 
            // btn_kembali
            // 
            this.btn_kembali.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(186)))), ((int)(((byte)(68)))));
            this.btn_kembali.Font = new System.Drawing.Font("Cambria", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_kembali.Location = new System.Drawing.Point(1196, 822);
            this.btn_kembali.Name = "btn_kembali";
            this.btn_kembali.Size = new System.Drawing.Size(128, 44);
            this.btn_kembali.TabIndex = 3;
            this.btn_kembali.Text = "Kembali";
            this.btn_kembali.UseVisualStyleBackColor = false;
            this.btn_kembali.Click += new System.EventHandler(this.btn_kembali_Click);
            // 
            // lb_bestMerchant
            // 
            this.lb_bestMerchant.AutoSize = true;
            this.lb_bestMerchant.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_bestMerchant.Location = new System.Drawing.Point(8, 20);
            this.lb_bestMerchant.Name = "lb_bestMerchant";
            this.lb_bestMerchant.Size = new System.Drawing.Size(336, 32);
            this.lb_bestMerchant.TabIndex = 4;
            this.lb_bestMerchant.Text = "Penjualan Terbaik Merchant";
            // 
            // lb_potonganTerbanyak
            // 
            this.lb_potonganTerbanyak.AutoSize = true;
            this.lb_potonganTerbanyak.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_potonganTerbanyak.Location = new System.Drawing.Point(21, 20);
            this.lb_potonganTerbanyak.Name = "lb_potonganTerbanyak";
            this.lb_potonganTerbanyak.Size = new System.Drawing.Size(247, 32);
            this.lb_potonganTerbanyak.TabIndex = 6;
            this.lb_potonganTerbanyak.Text = "Potongan Terbanyak";
            // 
            // lb_pesananWA
            // 
            this.lb_pesananWA.AutoSize = true;
            this.lb_pesananWA.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_pesananWA.Location = new System.Drawing.Point(9, 20);
            this.lb_pesananWA.Name = "lb_pesananWA";
            this.lb_pesananWA.Size = new System.Drawing.Size(299, 32);
            this.lb_pesananWA.TabIndex = 7;
            this.lb_pesananWA.Text = "Total Pesanan WhatsApp";
            // 
            // lb_akumulasi
            // 
            this.lb_akumulasi.AutoSize = true;
            this.lb_akumulasi.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_akumulasi.Location = new System.Drawing.Point(12, 20);
            this.lb_akumulasi.Name = "lb_akumulasi";
            this.lb_akumulasi.Size = new System.Drawing.Size(278, 32);
            this.lb_akumulasi.TabIndex = 8;
            this.lb_akumulasi.Text = "Akumulasi Pendapatan";
            // 
            // lb_hasilBestMerchant
            // 
            this.lb_hasilBestMerchant.AutoSize = true;
            this.lb_hasilBestMerchant.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_hasilBestMerchant.Location = new System.Drawing.Point(16, 11);
            this.lb_hasilBestMerchant.Name = "lb_hasilBestMerchant";
            this.lb_hasilBestMerchant.Size = new System.Drawing.Size(32, 32);
            this.lb_hasilBestMerchant.TabIndex = 12;
            this.lb_hasilBestMerchant.Text = "...";
            // 
            // lb_hasilPotonganTerbanyak
            // 
            this.lb_hasilPotonganTerbanyak.AutoSize = true;
            this.lb_hasilPotonganTerbanyak.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_hasilPotonganTerbanyak.Location = new System.Drawing.Point(21, 81);
            this.lb_hasilPotonganTerbanyak.Name = "lb_hasilPotonganTerbanyak";
            this.lb_hasilPotonganTerbanyak.Size = new System.Drawing.Size(32, 32);
            this.lb_hasilPotonganTerbanyak.TabIndex = 13;
            this.lb_hasilPotonganTerbanyak.Text = "...";
            // 
            // lb_hasilPesananWA
            // 
            this.lb_hasilPesananWA.AutoSize = true;
            this.lb_hasilPesananWA.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_hasilPesananWA.Location = new System.Drawing.Point(13, 69);
            this.lb_hasilPesananWA.Name = "lb_hasilPesananWA";
            this.lb_hasilPesananWA.Size = new System.Drawing.Size(32, 32);
            this.lb_hasilPesananWA.TabIndex = 14;
            this.lb_hasilPesananWA.Text = "...";
            // 
            // lb_hasilAkumulasi
            // 
            this.lb_hasilAkumulasi.AutoSize = true;
            this.lb_hasilAkumulasi.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_hasilAkumulasi.Location = new System.Drawing.Point(12, 81);
            this.lb_hasilAkumulasi.Name = "lb_hasilAkumulasi";
            this.lb_hasilAkumulasi.Size = new System.Drawing.Size(32, 32);
            this.lb_hasilAkumulasi.TabIndex = 15;
            this.lb_hasilAkumulasi.Text = "...";
            // 
            // lb_menu1
            // 
            this.lb_menu1.AutoSize = true;
            this.lb_menu1.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_menu1.Location = new System.Drawing.Point(21, 12);
            this.lb_menu1.Name = "lb_menu1";
            this.lb_menu1.Size = new System.Drawing.Size(32, 32);
            this.lb_menu1.TabIndex = 17;
            this.lb_menu1.Text = "...";
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(123)))), ((int)(((byte)(78)))));
            this.panel.Controls.Add(this.btn_beranda);
            this.panel.Controls.Add(this.btn_penjualan);
            this.panel.Controls.Add(this.btn_riwayat);
            this.panel.Controls.Add(this.btn_produk);
            this.panel.Controls.Add(this.btn_pesan);
            this.panel.Controls.Add(this.pictureBox2);
            this.panel.Location = new System.Drawing.Point(0, -56);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(250, 955);
            this.panel.TabIndex = 19;
            // 
            // btn_beranda
            // 
            this.btn_beranda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(186)))), ((int)(((byte)(68)))));
            this.btn_beranda.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_beranda.Location = new System.Drawing.Point(28, 350);
            this.btn_beranda.Name = "btn_beranda";
            this.btn_beranda.Size = new System.Drawing.Size(190, 70);
            this.btn_beranda.TabIndex = 8;
            this.btn_beranda.Text = "Beranda";
            this.btn_beranda.UseVisualStyleBackColor = false;
            this.btn_beranda.Click += new System.EventHandler(this.btn_beranda_Click_1);
            // 
            // btn_penjualan
            // 
            this.btn_penjualan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(186)))), ((int)(((byte)(68)))));
            this.btn_penjualan.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_penjualan.Location = new System.Drawing.Point(28, 791);
            this.btn_penjualan.Name = "btn_penjualan";
            this.btn_penjualan.Size = new System.Drawing.Size(190, 70);
            this.btn_penjualan.TabIndex = 7;
            this.btn_penjualan.Text = "Penjualan";
            this.btn_penjualan.UseVisualStyleBackColor = false;
            this.btn_penjualan.Click += new System.EventHandler(this.btn_penjualan_Click_1);
            // 
            // btn_riwayat
            // 
            this.btn_riwayat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(186)))), ((int)(((byte)(68)))));
            this.btn_riwayat.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_riwayat.Location = new System.Drawing.Point(28, 680);
            this.btn_riwayat.Name = "btn_riwayat";
            this.btn_riwayat.Size = new System.Drawing.Size(190, 70);
            this.btn_riwayat.TabIndex = 6;
            this.btn_riwayat.Text = "Riwayat";
            this.btn_riwayat.UseVisualStyleBackColor = false;
            this.btn_riwayat.Click += new System.EventHandler(this.btn_riwayat_Click_1);
            // 
            // btn_produk
            // 
            this.btn_produk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(186)))), ((int)(((byte)(68)))));
            this.btn_produk.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_produk.Location = new System.Drawing.Point(28, 570);
            this.btn_produk.Name = "btn_produk";
            this.btn_produk.Size = new System.Drawing.Size(190, 70);
            this.btn_produk.TabIndex = 5;
            this.btn_produk.Text = "Produk";
            this.btn_produk.UseVisualStyleBackColor = false;
            this.btn_produk.Click += new System.EventHandler(this.btn_produk_Click_1);
            // 
            // btn_pesan
            // 
            this.btn_pesan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(186)))), ((int)(((byte)(68)))));
            this.btn_pesan.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pesan.Location = new System.Drawing.Point(28, 459);
            this.btn_pesan.Name = "btn_pesan";
            this.btn_pesan.Size = new System.Drawing.Size(190, 70);
            this.btn_pesan.TabIndex = 4;
            this.btn_pesan.Text = "Pesan";
            this.btn_pesan.UseVisualStyleBackColor = false;
            this.btn_pesan.Click += new System.EventHandler(this.btn_pesan_Click_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Jreng_Kitchen.Properties.Resources.logo_jreng_kitchen;
            this.pictureBox2.Location = new System.Drawing.Point(28, 88);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(190, 181);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // panel_bestMerchant
            // 
            this.panel_bestMerchant.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(186)))), ((int)(((byte)(68)))));
            this.panel_bestMerchant.Controls.Add(this.pb_satu);
            this.panel_bestMerchant.Controls.Add(this.panel_hasilBestMerchant);
            this.panel_bestMerchant.Controls.Add(this.lb_bestMerchant);
            this.panel_bestMerchant.Location = new System.Drawing.Point(289, 306);
            this.panel_bestMerchant.Name = "panel_bestMerchant";
            this.panel_bestMerchant.Size = new System.Drawing.Size(370, 158);
            this.panel_bestMerchant.TabIndex = 20;
            this.panel_bestMerchant.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_bestMerchant_Paint);
            // 
            // pb_satu
            // 
            this.pb_satu.BackColor = System.Drawing.Color.Transparent;
            this.pb_satu.Image = global::Jreng_Kitchen.Properties.Resources._4;
            this.pb_satu.Location = new System.Drawing.Point(289, 81);
            this.pb_satu.Name = "pb_satu";
            this.pb_satu.Size = new System.Drawing.Size(55, 50);
            this.pb_satu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_satu.TabIndex = 34;
            this.pb_satu.TabStop = false;
            // 
            // panel_hasilBestMerchant
            // 
            this.panel_hasilBestMerchant.BackColor = System.Drawing.Color.White;
            this.panel_hasilBestMerchant.Controls.Add(this.lb_hasilBestMerchant);
            this.panel_hasilBestMerchant.Location = new System.Drawing.Point(14, 80);
            this.panel_hasilBestMerchant.Name = "panel_hasilBestMerchant";
            this.panel_hasilBestMerchant.Size = new System.Drawing.Size(261, 56);
            this.panel_hasilBestMerchant.TabIndex = 33;
            this.panel_hasilBestMerchant.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_hasilBestMerchant_Paint);
            // 
            // panel_potonganTerbanyak
            // 
            this.panel_potonganTerbanyak.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(186)))), ((int)(((byte)(68)))));
            this.panel_potonganTerbanyak.Controls.Add(this.lb_potonganTerbanyak);
            this.panel_potonganTerbanyak.Controls.Add(this.lb_hasilPotonganTerbanyak);
            this.panel_potonganTerbanyak.Location = new System.Drawing.Point(677, 306);
            this.panel_potonganTerbanyak.Name = "panel_potonganTerbanyak";
            this.panel_potonganTerbanyak.Size = new System.Drawing.Size(301, 158);
            this.panel_potonganTerbanyak.TabIndex = 21;
            this.panel_potonganTerbanyak.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_potonganTerbanyak_Paint);
            // 
            // panel_pesananWA
            // 
            this.panel_pesananWA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(186)))), ((int)(((byte)(68)))));
            this.panel_pesananWA.Controls.Add(this.lb_pesananWA);
            this.panel_pesananWA.Controls.Add(this.lb_hasilPesananWA);
            this.panel_pesananWA.Location = new System.Drawing.Point(998, 608);
            this.panel_pesananWA.Name = "panel_pesananWA";
            this.panel_pesananWA.Size = new System.Drawing.Size(326, 123);
            this.panel_pesananWA.TabIndex = 22;
            this.panel_pesananWA.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_pesananWA_Paint);
            // 
            // panel_akumulasi
            // 
            this.panel_akumulasi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(186)))), ((int)(((byte)(68)))));
            this.panel_akumulasi.Controls.Add(this.lb_garis);
            this.panel_akumulasi.Controls.Add(this.panel_laporanPeriode);
            this.panel_akumulasi.Controls.Add(this.lb_laporanPeriode);
            this.panel_akumulasi.Controls.Add(this.lb_hasilAkumulasi);
            this.panel_akumulasi.Controls.Add(this.lb_akumulasi);
            this.panel_akumulasi.Location = new System.Drawing.Point(998, 306);
            this.panel_akumulasi.Name = "panel_akumulasi";
            this.panel_akumulasi.Size = new System.Drawing.Size(326, 284);
            this.panel_akumulasi.TabIndex = 23;
            this.panel_akumulasi.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_akumulasi_Paint);
            // 
            // lb_garis
            // 
            this.lb_garis.AutoSize = true;
            this.lb_garis.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_garis.Location = new System.Drawing.Point(9, 112);
            this.lb_garis.Name = "lb_garis";
            this.lb_garis.Size = new System.Drawing.Size(304, 32);
            this.lb_garis.TabIndex = 33;
            this.lb_garis.Text = "_____________________________";
            // 
            // panel_laporanPeriode
            // 
            this.panel_laporanPeriode.BackColor = System.Drawing.Color.White;
            this.panel_laporanPeriode.Controls.Add(this.lb_bulanTahun);
            this.panel_laporanPeriode.Location = new System.Drawing.Point(34, 208);
            this.panel_laporanPeriode.Name = "panel_laporanPeriode";
            this.panel_laporanPeriode.Size = new System.Drawing.Size(236, 56);
            this.panel_laporanPeriode.TabIndex = 32;
            this.panel_laporanPeriode.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_laporanPeriode_Paint);
            // 
            // lb_bulanTahun
            // 
            this.lb_bulanTahun.AutoSize = true;
            this.lb_bulanTahun.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_bulanTahun.Location = new System.Drawing.Point(14, 12);
            this.lb_bulanTahun.Name = "lb_bulanTahun";
            this.lb_bulanTahun.Size = new System.Drawing.Size(32, 32);
            this.lb_bulanTahun.TabIndex = 17;
            this.lb_bulanTahun.Text = "...";
            // 
            // lb_laporanPeriode
            // 
            this.lb_laporanPeriode.AutoSize = true;
            this.lb_laporanPeriode.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_laporanPeriode.Location = new System.Drawing.Point(48, 152);
            this.lb_laporanPeriode.Name = "lb_laporanPeriode";
            this.lb_laporanPeriode.Size = new System.Drawing.Size(203, 32);
            this.lb_laporanPeriode.TabIndex = 16;
            this.lb_laporanPeriode.Text = "Laporan Periode";
            // 
            // panel_menu1
            // 
            this.panel_menu1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(186)))), ((int)(((byte)(68)))));
            this.panel_menu1.Controls.Add(this.lb_menu1);
            this.panel_menu1.Controls.Add(this.pb_rank1);
            this.panel_menu1.Location = new System.Drawing.Point(289, 514);
            this.panel_menu1.Name = "panel_menu1";
            this.panel_menu1.Size = new System.Drawing.Size(689, 58);
            this.panel_menu1.TabIndex = 27;
            this.panel_menu1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_menu1_Paint);
            // 
            // pb_rank1
            // 
            this.pb_rank1.BackColor = System.Drawing.Color.Transparent;
            this.pb_rank1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pb_rank1.Image = global::Jreng_Kitchen.Properties.Resources._4;
            this.pb_rank1.Location = new System.Drawing.Point(617, 5);
            this.pb_rank1.Name = "pb_rank1";
            this.pb_rank1.Size = new System.Drawing.Size(55, 50);
            this.pb_rank1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_rank1.TabIndex = 35;
            this.pb_rank1.TabStop = false;
            // 
            // panel_menu2
            // 
            this.panel_menu2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(186)))), ((int)(((byte)(68)))));
            this.panel_menu2.Controls.Add(this.lb_menu2);
            this.panel_menu2.Controls.Add(this.pb_rank2);
            this.panel_menu2.Location = new System.Drawing.Point(289, 588);
            this.panel_menu2.Name = "panel_menu2";
            this.panel_menu2.Size = new System.Drawing.Size(689, 58);
            this.panel_menu2.TabIndex = 28;
            this.panel_menu2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_menu2_Paint);
            // 
            // lb_menu2
            // 
            this.lb_menu2.AutoSize = true;
            this.lb_menu2.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_menu2.Location = new System.Drawing.Point(21, 12);
            this.lb_menu2.Name = "lb_menu2";
            this.lb_menu2.Size = new System.Drawing.Size(32, 32);
            this.lb_menu2.TabIndex = 17;
            this.lb_menu2.Text = "...";
            // 
            // pb_rank2
            // 
            this.pb_rank2.BackColor = System.Drawing.Color.Transparent;
            this.pb_rank2.Image = global::Jreng_Kitchen.Properties.Resources._5;
            this.pb_rank2.Location = new System.Drawing.Point(617, 4);
            this.pb_rank2.Name = "pb_rank2";
            this.pb_rank2.Size = new System.Drawing.Size(55, 50);
            this.pb_rank2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_rank2.TabIndex = 36;
            this.pb_rank2.TabStop = false;
            // 
            // panel_menu3
            // 
            this.panel_menu3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(186)))), ((int)(((byte)(68)))));
            this.panel_menu3.Controls.Add(this.pb_rank3);
            this.panel_menu3.Controls.Add(this.lb_menu3);
            this.panel_menu3.Location = new System.Drawing.Point(289, 661);
            this.panel_menu3.Name = "panel_menu3";
            this.panel_menu3.Size = new System.Drawing.Size(689, 58);
            this.panel_menu3.TabIndex = 29;
            this.panel_menu3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_menu3_Paint);
            // 
            // pb_rank3
            // 
            this.pb_rank3.BackColor = System.Drawing.Color.Transparent;
            this.pb_rank3.Image = global::Jreng_Kitchen.Properties.Resources._6;
            this.pb_rank3.Location = new System.Drawing.Point(617, 2);
            this.pb_rank3.Name = "pb_rank3";
            this.pb_rank3.Size = new System.Drawing.Size(55, 50);
            this.pb_rank3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_rank3.TabIndex = 37;
            this.pb_rank3.TabStop = false;
            // 
            // lb_menu3
            // 
            this.lb_menu3.AutoSize = true;
            this.lb_menu3.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_menu3.Location = new System.Drawing.Point(21, 12);
            this.lb_menu3.Name = "lb_menu3";
            this.lb_menu3.Size = new System.Drawing.Size(32, 32);
            this.lb_menu3.TabIndex = 17;
            this.lb_menu3.Text = "...";
            // 
            // lb_menu4
            // 
            this.lb_menu4.AutoSize = true;
            this.lb_menu4.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_menu4.Location = new System.Drawing.Point(20, 12);
            this.lb_menu4.Name = "lb_menu4";
            this.lb_menu4.Size = new System.Drawing.Size(32, 32);
            this.lb_menu4.TabIndex = 18;
            this.lb_menu4.Text = "...";
            // 
            // panel_menu4
            // 
            this.panel_menu4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(186)))), ((int)(((byte)(68)))));
            this.panel_menu4.Controls.Add(this.lb_menu4);
            this.panel_menu4.Location = new System.Drawing.Point(289, 735);
            this.panel_menu4.Name = "panel_menu4";
            this.panel_menu4.Size = new System.Drawing.Size(689, 58);
            this.panel_menu4.TabIndex = 30;
            this.panel_menu4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_menu4_Paint);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(186)))), ((int)(((byte)(68)))));
            this.panel1.Controls.Add(this.lb_menu5);
            this.panel1.Location = new System.Drawing.Point(289, 808);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(689, 58);
            this.panel1.TabIndex = 31;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lb_menu5
            // 
            this.lb_menu5.AutoSize = true;
            this.lb_menu5.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_menu5.Location = new System.Drawing.Point(21, 12);
            this.lb_menu5.Name = "lb_menu5";
            this.lb_menu5.Size = new System.Drawing.Size(32, 32);
            this.lb_menu5.TabIndex = 18;
            this.lb_menu5.Text = "...";
            // 
            // lb_menuFavorit
            // 
            this.lb_menuFavorit.AutoSize = true;
            this.lb_menuFavorit.Font = new System.Drawing.Font("Cambria", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_menuFavorit.Location = new System.Drawing.Point(297, 472);
            this.lb_menuFavorit.Name = "lb_menuFavorit";
            this.lb_menuFavorit.Size = new System.Drawing.Size(165, 32);
            this.lb_menuFavorit.TabIndex = 13;
            this.lb_menuFavorit.Text = "Menu Favorit";
            // 
            // btn_penjual
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1364, 889);
            this.Controls.Add(this.lb_menuFavorit);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_menu4);
            this.Controls.Add(this.panel_menu3);
            this.Controls.Add(this.panel_menu2);
            this.Controls.Add(this.panel_menu1);
            this.Controls.Add(this.panel_akumulasi);
            this.Controls.Add(this.panel_pesananWA);
            this.Controls.Add(this.panel_potonganTerbanyak);
            this.Controls.Add(this.panel_bestMerchant);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.btn_kembali);
            this.Controls.Add(this.lb_laporanPenjualan);
            this.Controls.Add(this.dgv_laporan);
            this.Name = "btn_penjual";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormLaporan";
            this.Load += new System.EventHandler(this.FormLaporan_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_laporan)).EndInit();
            this.panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel_bestMerchant.ResumeLayout(false);
            this.panel_bestMerchant.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_satu)).EndInit();
            this.panel_hasilBestMerchant.ResumeLayout(false);
            this.panel_hasilBestMerchant.PerformLayout();
            this.panel_potonganTerbanyak.ResumeLayout(false);
            this.panel_potonganTerbanyak.PerformLayout();
            this.panel_pesananWA.ResumeLayout(false);
            this.panel_pesananWA.PerformLayout();
            this.panel_akumulasi.ResumeLayout(false);
            this.panel_akumulasi.PerformLayout();
            this.panel_laporanPeriode.ResumeLayout(false);
            this.panel_laporanPeriode.PerformLayout();
            this.panel_menu1.ResumeLayout(false);
            this.panel_menu1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_rank1)).EndInit();
            this.panel_menu2.ResumeLayout(false);
            this.panel_menu2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_rank2)).EndInit();
            this.panel_menu3.ResumeLayout(false);
            this.panel_menu3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_rank3)).EndInit();
            this.panel_menu4.ResumeLayout(false);
            this.panel_menu4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_laporan;
        private System.Windows.Forms.Label lb_laporanPenjualan;
        private System.Windows.Forms.Button btn_kembali;
        private System.Windows.Forms.Label lb_bestMerchant;
        private System.Windows.Forms.Label lb_potonganTerbanyak;
        private System.Windows.Forms.Label lb_pesananWA;
        private System.Windows.Forms.Label lb_akumulasi;
        private System.Windows.Forms.Label lb_hasilBestMerchant;
        private System.Windows.Forms.Label lb_hasilPotonganTerbanyak;
        private System.Windows.Forms.Label lb_hasilPesananWA;
        private System.Windows.Forms.Label lb_hasilAkumulasi;
        private System.Windows.Forms.Label lb_menu1;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Button btn_beranda;
        private System.Windows.Forms.Button btn_penjualan;
        private System.Windows.Forms.Button btn_riwayat;
        private System.Windows.Forms.Button btn_produk;
        private System.Windows.Forms.Button btn_pesan;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel_bestMerchant;
        private System.Windows.Forms.Panel panel_potonganTerbanyak;
        private System.Windows.Forms.Panel panel_pesananWA;
        private System.Windows.Forms.Panel panel_akumulasi;
        private System.Windows.Forms.Label lb_laporanPeriode;
        private System.Windows.Forms.Label lb_bulanTahun;
        private System.Windows.Forms.Panel panel_menu1;
        private System.Windows.Forms.Panel panel_menu2;
        private System.Windows.Forms.Label lb_menu2;
        private System.Windows.Forms.Panel panel_menu3;
        private System.Windows.Forms.Label lb_menu3;
        private System.Windows.Forms.Label lb_menu4;
        private System.Windows.Forms.Panel panel_menu4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lb_menu5;
        private System.Windows.Forms.Label lb_menuFavorit;
        private System.Windows.Forms.Panel panel_laporanPeriode;
        private System.Windows.Forms.Label lb_garis;
        private System.Windows.Forms.Panel panel_hasilBestMerchant;
        private System.Windows.Forms.PictureBox pb_satu;
        private System.Windows.Forms.PictureBox pb_rank1;
        private System.Windows.Forms.PictureBox pb_rank2;
        private System.Windows.Forms.PictureBox pb_rank3;
    }
}